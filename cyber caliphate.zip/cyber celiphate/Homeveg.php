<head>
  <meta charset="utf-8"
  <meta name="viewport" content="width-device-width, initial-scale-1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="Homevegstyle.css">
<header id="showcase">

    <h1>Welcome To Home Garden</h1>
    <p>Create your own food garden.</p>
    <br>

  <div class="btn-group">
    <a href="tryreg.php" class="button">Sign up</a>&nbsp;<a href="trylog.html" class="button">Log in </a>
  </div>
  </header>
    <section id="section-a">
    <p>Home Garden helps you grow your own fruits and vegetables by providing you with information about the cultivation methods of various plants. Enables you to track the progress of your plants and connects you to other gardeners to trade crops.</p>
  </section>
