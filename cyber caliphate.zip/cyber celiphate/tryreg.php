
<?php
if($_POST)
{
	
  $errors = array();

if(empty($_POST['name']))
{
	$errors['name'] = "Please Enter Your Name!";
}
if(empty($_POST['surn']))
{
	$errors['surn'] = "Please Enter Your Surname!";
}
if(empty($_POST['email']))
{
	$errors['email'] = "Please Enter a vaild email!";
}

if(empty($_POST['celln']))
{
	$errors['celln'] = "Cellphone number cannot be empty!";
}

if(empty($_POST['pass']))
{
	$errors['pass'] = "Password cannot be empty !";
}
if(strlen($_POST['pass']) < 8)
{
	$errors['pass'] = "Password cannot be less than 8 characters long";
}
if(empty($_POST['pass2']))
{
	$errors['pass2'] = "Confirm Email!";
}

if(count($errors)== 0)
      {
	header( "Location: success.php");
	exit();
	  }


}


?>




<html>
<head>
<title>tryregister</title>
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="mystyle.css" type="text/css">



<body>
<center>
<form method="POST" target="" class="containerr" display="flex">
<pre>
<h3>Register Account</h3>
 <label for="name" >Name</label>        <input type="text" id="name" name="name" placeholder="enter your name"/>
 <?php if(isset($errors['name'])) echo $errors['name'];?>
 
 <label for="surn" >Surname</label>     <input type="text" id="surn" name="surn" placeholder="enter your surname"/>
 <?php if(isset($errors['surn'])) echo $errors['surn'];?>
 
 <label for="email">Email</label>       <input type="text" id="email" name="email" placeholder="enter your email address"/>
 <?php if(isset($errors['email'])) echo $errors['email'];?>

 <label for="celln">Cell No</label>     <input type="text" id="celln" name="celln" placeholder="enter your cell no"/>
 <?php if(isset($errors['celln'])) echo $errors['celln'];?>
 
 <label for="pass"  >Password</label>
<input type="password" id="pass" name="pass" placeholder="enter desired password"/>
<?php if(isset($errors['pass'])) echo $errors['pass'];?>

<label for="pass2" >Enter Password Again</label>
<input type="password" id="pass2" name="pass2" placeholder="enter the password again"/>
<?php if(isset($errors['pass2'])) echo $errors['pass2'];?>

<button type="submit" class="btn2">Register</button>

</pre>
</form>
</center>




<script src="jquery-3.3.1.min.js"></script>
<script src="bootstrap/js.bootstrap.min.js"></script>
<script src="main.js"></script>
</body>
</html>